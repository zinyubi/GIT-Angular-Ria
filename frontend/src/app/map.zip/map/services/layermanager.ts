import { Injectable } from '@angular/core';
import { RasterTileSetLayer } from '@luciad/ria/view/tileset/RasterTileSetLayer.js';
import { FusionTileSetModel } from '@luciad/ria/model/tileset/FusionTileSetModel.js';
import { WMSTileSetModel } from '@luciad/ria/model/tileset/WMSTileSetModel.js';
import { getReference } from '@luciad/ria/reference/ReferenceProvider.js';
import { createBounds } from '@luciad/ria/shape/ShapeFactory.js';
import { LayerType } from '@luciad/ria/view/LayerType.js';
import { GridLayer } from '@luciad/ria/view/grid/GridLayer.js';
import { LonLatGrid } from '@luciad/ria/view/grid/LonLatGrid.js';
import { LonLatPointFormat } from '@luciad/ria/shape/format/LonLatPointFormat.js';
import { RasterDataType } from '@luciad/ria/model/tileset/RasterDataType.js';
import { RasterSamplingMode } from '@luciad/ria/model/tileset/RasterSamplingMode.js';
import type { WebGLMap } from '@luciad/ria/view/WebGLMap.js';

@Injectable({ providedIn: 'root' })
export class BaseLayerService {
  private map?: WebGLMap;

  async setupInitialLayers(map: WebGLMap): Promise<void> {
    this.map = map;
    try {
      await this.createBaseLayers();
      console.log('Base layers created successfully');
    } catch (error) {
      console.error('Error creating base layers:', error);
      throw error;
    }
  }

  private async createBaseLayers(): Promise<void> {
    if (!this.map) throw new Error('Map not set in BaseLayerService');

    // Create WMS Base Layer
    const wmsServer = 'https://sampleservices.luciad.com/wms';
    const wmsLayerName = '4ceea49c-3e7c-4e2d-973d-c608fb2fb07e';

    const wmsModel = await WMSTileSetModel.createFromURL(wmsServer, [{ layer: wmsLayerName }]);
    const wmsLayer = new RasterTileSetLayer(wmsModel, {
      label: 'Base WMS Layer',
      layerType: LayerType.BASE,
    });

    // Elevation Layer
    const elevationLayer = await this.createFusionElevationLayer();

    // Grid Layer
    const gridLayer = this.createGridLayer();

    // Add layers in stacking order: base at bottom, grid at top
    this.map.layerTree.addChild(wmsLayer);
    this.map.layerTree.addChild(elevationLayer, 'above', wmsLayer);
    this.map.layerTree.addChild(gridLayer, 'above', elevationLayer);
  }

  private async createFusionElevationLayer(): Promise<RasterTileSetLayer> {
    const elevationParameters = {
      structure: {
        reference: getReference('EPSG:4326'),
        level0Columns: 4,
        level0Rows: 2,
        levelCount: 24,
        bounds: createBounds(getReference('EPSG:4326'), [-180, 180, -90, 90]), // Correct bounds
        tileWidth: 32,
        tileHeight: 32,
      },
      url: 'https://sampleservices.luciad.com/lts',
      coverageId: 'e8f28a35-0e8c-4210-b2e8-e5d4333824ec',
      dataType: RasterDataType.ELEVATION,
      samplingMode: RasterSamplingMode.POINT,
    };

    const fusionTileSetModel = new FusionTileSetModel(elevationParameters);
    return new RasterTileSetLayer(fusionTileSetModel, {
      label: 'Elevation',
    });
  }

  private createGridLayer(): GridLayer {
    const gridSettings = [
      { scale: 40000.0e-9, deltaLon: 1 / 60, deltaLat: 1 / 60 },
      { scale: 20000.0e-9, deltaLon: 1 / 30, deltaLat: 1 / 30 },
      { scale: 10000.0e-9, deltaLon: 1 / 10, deltaLat: 1 / 10 },
      { scale: 5000.0e-9, deltaLon: 1 / 2, deltaLat: 1 / 2 },
      { scale: 1000.0e-9, deltaLon: 1, deltaLat: 1 },
      { scale: 200.0e-9, deltaLon: 5, deltaLat: 5 },
      { scale: 20.0e-9, deltaLon: 10, deltaLat: 10 },
      { scale: 9.0e-9, deltaLon: 20, deltaLat: 20 },
      { scale: 5.0e-9, deltaLon: 30, deltaLat: 30 },
      { scale: 0, deltaLon: 45, deltaLat: 45 },
    ];

    const lonlatGridFallBack = {
      labelFormat: new LonLatPointFormat({ pattern: 'lat(+DM),lon(+DM)' }),
      originLabelFormat: new LonLatPointFormat({ pattern: 'lat(+D),lon(+D)' }),
      originLineStyle: { color: 'rgba(230, 20, 20, 0.6)', width: 2 },
      lineStyle: { color: 'rgba(210,210,210,0.6)', width: 1 },
    };

    const lonLatGrid = new LonLatGrid(gridSettings);
    lonLatGrid.fallbackStyle = lonlatGridFallBack;
    return new GridLayer(lonLatGrid);
  }
}
