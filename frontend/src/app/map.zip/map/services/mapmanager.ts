import { Injectable } from '@angular/core';
import { WebGLMap } from '@luciad/ria/view/WebGLMap.js';
import { getReference } from '@luciad/ria/reference/ReferenceProvider.js';
import { createPoint, createBounds } from '@luciad/ria/shape/ShapeFactory.js';
import { RasterTileSetLayer } from '@luciad/ria/view/tileset/RasterTileSetLayer.js';
import { LayerType } from '@luciad/ria/view/LayerType.js';
import { GridLayer } from '@luciad/ria/view/grid/GridLayer.js';

@Injectable({ providedIn: 'root' })
export class MapManager {
  private map?: WebGLMap;

  async initializeMap(domNodeID: string): Promise<void> {
    this.createMap(getReference('EPSG:4326'), false, domNodeID);
  }

  private createMap(reference: any, use3D: boolean, domNodeID?: string): void {
    const nodeID = domNodeID || this.map?.domNode?.id || 'luciadMap';

    this.map = new WebGLMap(nodeID, {
      reference,
      wrapAroundWorld: false,
      autoAdjustDisplayScale: true,
    });

    if (!use3D) {
      this.setupFor2D();
    } else {
      this.setupFor3D();
    }
  }

  private setupFor2D(): void {
    if (this.map?.camera) {
      const camera = this.map.camera as any;
      if (typeof camera.setLook2D === 'function') {
        camera.setLook2D();
      }
    }
  }

  private setupFor3D(): void {
    if (this.map?.camera) {
      const camera = this.map.camera as any;
      if (typeof camera.setLook3D === 'function') {
        camera.setLook3D();
      }
    }
  }

  async createBaseLayers(): Promise<void> {
    // Dynamic imports for better startup performance
    const { WMSTileSetModel } = await import('@luciad/ria/model/tileset/WMSTileSetModel.js');
    const wmsServer = 'https://sampleservices.luciad.com/wms';
    const wmsLayerName = '4ceea49c-3e7c-4e2d-973d-c608fb2fb07e';

    const wmsModel = await WMSTileSetModel.createFromURL(wmsServer, [{ layer: wmsLayerName }]);
    const wmsLayer = new RasterTileSetLayer(wmsModel, {
      label: 'Base WMS Layer',
      layerType: LayerType.BASE,
    });

    const elevationLayer = await this.createFusionElevationLayer();
    const gridLayer = await this.createGridLayer();

    if (!this.map) throw new Error('Map is not initialized');

    this.map.layerTree.addChild(wmsLayer);
    this.map.layerTree.addChild(elevationLayer, 'above', wmsLayer);
    this.map.layerTree.addChild(gridLayer, 'above', elevationLayer);
  }

  private async createFusionElevationLayer(): Promise<RasterTileSetLayer> {
    const { FusionTileSetModel } = await import('@luciad/ria/model/tileset/FusionTileSetModel.js');
    const { RasterDataType } = await import('@luciad/ria/model/tileset/RasterDataType.js');
    const { RasterSamplingMode } = await import('@luciad/ria/model/tileset/RasterSamplingMode.js');

    const elevationParameters = {
      structure: {
        reference: getReference('EPSG:4326'),
        level0Columns: 4,
        level0Rows: 2,
        levelCount: 24,
        bounds: createBounds(getReference('EPSG:4326'), [-180, 180, -90, 90]),
        tileWidth: 32,
        tileHeight: 32,
      },
      url: 'https://sampleservices.luciad.com/lts',
      coverageId: 'e8f28a35-0e8c-4210-b2e8-e5d4333824ec',
      dataType: RasterDataType.ELEVATION,
      samplingMode: RasterSamplingMode.POINT,
    };

    const fusionTileSetModel = new FusionTileSetModel(elevationParameters);
    return new RasterTileSetLayer(fusionTileSetModel, {
      label: 'Elevation',
    });
  }

  private async createGridLayer(): Promise<GridLayer> {
    const { LonLatGrid } = await import('@luciad/ria/view/grid/LonLatGrid.js');
    const { LonLatPointFormat } = await import('@luciad/ria/shape/format/LonLatPointFormat.js');

    const gridSettings = [
      { scale: 40000.0e-9, deltaLon: 1 / 60, deltaLat: 1 / 60 },
      { scale: 20000.0e-9, deltaLon: 1 / 30, deltaLat: 1 / 30 },
      { scale: 10000.0e-9, deltaLon: 1 / 10, deltaLat: 1 / 10 },
      { scale: 5000.0e-9, deltaLon: 1 / 2, deltaLat: 1 / 2 },
      { scale: 1000.0e-9, deltaLon: 1, deltaLat: 1 },
      { scale: 200.0e-9, deltaLon: 5, deltaLat: 5 },
      { scale: 20.0e-9, deltaLon: 10, deltaLat: 10 },
      { scale: 9.0e-9, deltaLon: 20, deltaLat: 20 },
      { scale: 5.0e-9, deltaLon: 30, deltaLat: 30 },
      { scale: 0, deltaLon: 45, deltaLat: 45 },
    ];

    const lonlatGridFallBack = {
      labelFormat: new LonLatPointFormat({ pattern: 'lat(+DM),lon(+DM)' }),
      originLabelFormat: new LonLatPointFormat({ pattern: 'lat(+D),lon(+D)' }),
      originLineStyle: {
        color: 'rgba(230, 20, 20, 0.6)',
        width: 2,
      },
      lineStyle: {
        color: 'rgba(210,210,210,0.6)',
        width: 1,
      },
    };

    const lonLatGrid = new LonLatGrid(gridSettings);
    lonLatGrid.fallbackStyle = lonlatGridFallBack;
    return new GridLayer(lonLatGrid);
  }

  setView(center: { x: number; y: number }, zoom: number): void {
    if (!this.map) return;

    const reference = this.map.reference;
    const centerPoint = createPoint(reference, [center.x, center.y]);

    const defaultScale = 1000000 / zoom;

    // Uncomment and adjust if viewFit is available:
    // this.map.viewFit(centerPoint, { animate: true, scale: defaultScale });
  }

  restrictBounds(bounds: { minX: number; minY: number; maxX: number; maxY: number }): void {
    if (!this.map) return;

    const reference = this.map.reference;
    const navBounds = createBounds(reference, [bounds.minX, bounds.minY, bounds.maxX, bounds.maxY]);
    this.map.restrictNavigationToBounds(navBounds);
  }

  setDisplayScale(autoAdjust: boolean, fixedScale?: number): void {
    if (!this.map) return;

    this.map.autoAdjustDisplayScale = autoAdjust;
    if (!autoAdjust && fixedScale !== undefined) {
      this.map.displayScale = fixedScale;
    }
  }

  onMapEvent(event: string, callback: (...args: any[]) => void): void {
    if (!this.map) return;
    this.map.on(event as any, callback, this);
  }

  resize(): void {
    if (!this.map) return;
    this.map.resize();
  }

  destroy(): void {
    if (!this.map) return;
    this.map.destroy();
    this.map = undefined;
  }

  getMap(): WebGLMap | undefined {
    return this.map;
  }
}
