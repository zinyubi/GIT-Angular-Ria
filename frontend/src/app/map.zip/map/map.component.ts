import {
  Component,
  AfterViewInit,
  OnDestroy,
  HostListener,
  ElementRef,
  ViewChild,
} from '@angular/core';

import { MapManager } from './services/mapmanager';
import { ConfigManager } from './services/configmanager.service';
import { BaseLayerService } from "./services/layermanager";

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css'],
})
export class MapComponent implements AfterViewInit, OnDestroy {
  @ViewChild('luciadMap', { static: true }) mapContainerRef!: ElementRef;
  domNodeID = 'luciadMap';

  constructor(
    private mapManager: MapManager,
    private configManager: ConfigManager,
    private baseLayerService: BaseLayerService
  ) {}

  async ngAfterViewInit(): Promise<void> {
    try {
      await this.mapManager.initializeMap(this.domNodeID);

      const map = this.mapManager.getMap();
      if (!map) {
        throw new Error('Map not initialized properly.');
      }

      await this.baseLayerService.setupInitialLayers(map);
      console.log('All layers setup successfully');
    } catch (error) {
      console.warn('Layer setup failed or map initialization error:', error);
    }

    this.mapManager.setDisplayScale(true);
    this.mapManager.resize();
  }

  @HostListener('window:resize')
  onResize(): void {
    this.mapManager.resize();
  }

  ngOnDestroy(): void {
    this.mapManager.destroy();
  }
}